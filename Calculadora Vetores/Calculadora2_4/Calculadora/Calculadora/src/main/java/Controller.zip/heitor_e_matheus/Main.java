package heitor_e_matheus.calculadora;

import Interface.MainInterface;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainInterface.class, args);
    }
}
