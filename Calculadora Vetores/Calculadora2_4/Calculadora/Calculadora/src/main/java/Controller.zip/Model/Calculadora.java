package Model;

public class Calculadora {

    private double x1, y1, x2, y2;

    public Calculadora(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public double calcularVetoresPlano() {
        // Lógica para cálculo de vetores no plano
        return Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2));
    }

    public double calcularProdutoEscalar() {
        // Cálculo do produto escalar
        return (x1 * x2) + (y1 * y2);
    }

    public double calcularAnguloVetores() {
        // Cálculo do ângulo entre os vetores
        double produtoEscalar = calcularProdutoEscalar();
        double magnitudeA = Math.sqrt(x1 * x1 + y1 * y1);
        double magnitudeB = Math.sqrt(x2 * x2 + y2 * y2);
        return Math.acos(produtoEscalar / (magnitudeA * magnitudeB));
    }

    public double calcularProdutoVetorial() {
        // Cálculo do produto vetorial
        return (x1 * y2) - (y1 * x2);
    }

    // Getters e setters, se necessário
    public void setCoordenadas(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }
}
