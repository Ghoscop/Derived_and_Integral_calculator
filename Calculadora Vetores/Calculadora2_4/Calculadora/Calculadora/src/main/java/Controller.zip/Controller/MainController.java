package Controller;

import Model.Calculadora;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.media.MediaPlayer;

import java.util.ArrayList;
import java.util.List;

public class MainController {

    private Calculadora calculadora;
    private MediaPlayer mediaPlayer;

    @FXML
    private Pane paneTitulo;
    @FXML
    private Label labelResultado;
    @FXML
    private Label labelx1, labely1, labelx2, labely2;  // Usado para exibir as coordenadas
    @FXML
    private ChoiceBox<String> escolha;
    @FXML
    private ImageView btnFechar, btnMinimizar;
    @FXML
    private ImageView imgMode;
    @FXML
    private Pane fundoPane;

    private double x, y;
    private boolean isLightMode = true;

    private final List<Double> coordenadas = new ArrayList<>();
    private int fase = 0;  // Variável para controlar a fase da captura (x1, y1, x2, y2)

    public MainController() {
        this.calculadora = new Calculadora(0, 0, 0, 0);
    }

    public void inicio(Stage stage, MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;

        System.out.println("Código funcionando com sucesso!");
        stage.setTitle("Sonic Calculator");
        stage.setResizable(false);

        paneTitulo.setOnMousePressed(mouseEvent -> {
            x = mouseEvent.getSceneX();
            y = mouseEvent.getSceneY();
        });
        // Habilita as funções de minimizar e fechar
        paneTitulo.setOnMouseDragged(mouseEvent -> {
            stage.setX(mouseEvent.getScreenX() - x);
            stage.setY(mouseEvent.getScreenY() - y);
        });

        btnFechar.setOnMouseClicked(mouseEvent -> stage.close());
        btnMinimizar.setOnMouseClicked(mouseEvent -> stage.setIconified(true));

        escolha.getItems().add("Vetores no Plano");
        escolha.getItems().add("Produto Escalar");
        escolha.getItems().add("Ângulo entre Vetores");
        escolha.getItems().add("Produto Vetorial");
    }

    @FXML
    public void changeMode(ActionEvent event) {
        isLightMode = !isLightMode;
        if (isLightMode) {
            setLightMode();
        } else {
            setDarkMode();
        }
    }

    private void setLightMode() {
        fundoPane.getStylesheets().remove(getClass().getResource("/styles/DarkMode.css").toExternalForm());
        fundoPane.getStylesheets().add(getClass().getResource("/styles/LightMode.css").toExternalForm());

        Image image = new Image(getClass().getResource("/Imagens/dark.png").toExternalForm());
        imgMode.setImage(image);

        Image fundoImage = new Image(getClass().getResource("/Imagens/SonicPanel.png").toExternalForm());
        fundoPane.setStyle("-fx-background-image: url('" + fundoImage.getUrl() + "'); -fx-background-size: cover;");
    }

    private void setDarkMode() {
        fundoPane.getStylesheets().remove(getClass().getResource("/styles/LightMode.css").toExternalForm());
        fundoPane.getStylesheets().add(getClass().getResource("/styles/DarkMode.css").toExternalForm());

        Image image = new Image(getClass().getResource("/Imagens/light.png").toExternalForm());
        imgMode.setImage(image);

        Image fundoImage = new Image(getClass().getResource("/Imagens/mygod.png").toExternalForm());
        fundoPane.setStyle("-fx-background-image: url('" + fundoImage.getUrl() + "'); -fx-background-size: cover;");
    }

    // Função para capturar coordenadas em etapas (x1, y1, x2, y2)
    @FXML
    private void capturarCoordenadas(MouseEvent event) {
        // Obtém o valor atual de labelResultado (o valor que está sendo mostrado)
        double coordenada = Double.parseDouble(labelResultado.getText());

        // Fases de captura: x1 -> y1 -> x2 -> y2
        if (fase == 0) {
            coordenadas.add(coordenada);
            labelx1.setText(String.format("%.2f", coordenada));  // Atualiza o labelx1
            fase = 1;  // Vai para a próxima fase (y1)
        } else if (fase == 1) {
            coordenadas.add(coordenada);
            labely1.setText(String.format("%.2f", coordenada));  // Atualiza o labely1
            fase = 2;  // Vai para a próxima fase (x2)
        } else if (fase == 2) {
            coordenadas.add(coordenada);
            labelx2.setText(String.format("%.2f", coordenada));  // Atualiza o labelx2
            fase = 3;  // Vai para a próxima fase (y2)
        } else if (fase == 3) {
            coordenadas.add(coordenada);
            labely2.setText(String.format("%.2f", coordenada));  // Atualiza o labely2
            labelResultado.setText("Escolha uma operação e clique em Calcular");  // Instrução para o usuário
            fase = 4;  // Fase finalizada
        }
    }

    // Função que será chamada quando clicar no botão Igual
    @FXML
    private void noSinal(MouseEvent event) {
        String simbolo = ((Pane) event.getSource()).getId().replace("btn", "");

        if (simbolo.equals("Igual")) {
            // Antes de calcular, verifica se as coordenadas estão todas preenchidas
            if (fase == 4) {
                // Atualiza as coordenadas na classe Calculadora
                calculadora.setCoordenadas(
                        Double.parseDouble(labelx1.getText()),
                        Double.parseDouble(labely1.getText()),
                        Double.parseDouble(labelx2.getText()),
                        Double.parseDouble(labely2.getText())
                );

                // Realiza o cálculo com base na opção selecionada na ChoiceBox
                realizarCalculo();
            } else {
                // Caso as coordenadas não estejam completas
                labelResultado.setText("Complete as coordenadas!");
            }
        }
    }

    // Função para realizar o cálculo dependendo da opção selecionada na ChoiceBox
    private void realizarCalculo() {
        String opcao = escolha.getValue();
        double resultado = 0.0;

        // Executa o cálculo de acordo com a opção selecionada
        switch (opcao) {
            case "Vetores no Plano":
                resultado = calculadora.calcularVetoresPlano();
                break;
            case "Produto Escalar":
                resultado = calculadora.calcularProdutoEscalar();
                break;
            case "Ângulo entre Vetores":
                resultado = calculadora.calcularAnguloVetores();
                break;
            case "Produto Vetorial":
                resultado = calculadora.calcularProdutoVetorial();
                break;
            default:
                labelResultado.setText("Selecione uma operação");
                return;
        }

        // Exibe o resultado no labelResultado
        labelResultado.setText(String.format("%.2f", resultado));
    }

    // Função para capturar os números digitados
    @FXML
    private void noNumero(MouseEvent event) {
        // Obtém o valor do botão clicado a partir do ID do Pane
        int valor = Integer.parseInt(((Pane) event.getSource()).getId().replace("btn", ""));

        // Atualiza o labelResultado com o valor atual do botão pressionado
        String valorAtual = labelResultado.getText() + valor;  // Concatena o número pressionado
        labelResultado.setText(valorAtual);  // Atualiza o display com o número completo
    }
}
